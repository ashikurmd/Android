package com.ashik.myloginpagedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    DatabaseHelper databaseHelper;

    private Button signInButton,signUpHereButton;
    private EditText usernameEditText,passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signInButton = findViewById(R.id.signInButtonId);
        signUpHereButton = findViewById(R.id.signUpHereButtonId);
        usernameEditText = findViewById(R.id.signInUsernameEditTextId);
        passwordEditText = findViewById(R.id.signInPasswordEditTextId);


        databaseHelper = new DatabaseHelper(this);
       SQLiteDatabase sqLiteDatabase = databaseHelper.getReadableDatabase();

       signInButton.setOnClickListener(this);
       signUpHereButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

       String username = usernameEditText.getText().toString();
       String password = passwordEditText.getText().toString();


        if(v.getId()== R.id.signInButtonId){

            boolean result = databaseHelper.findPassword (username,password);

            if (result==true){

                Intent intent = new Intent(MainActivity.this,Main2Activity.class);
                startActivity(intent);
            } else {

                Toast.makeText(getApplicationContext(),"Username & Password did not match", Toast.LENGTH_LONG).show();
            }

        }
        else if(v.getId()== R.id.signUpHereButtonId){

            Intent intent = new Intent(MainActivity.this,SignUpActivity.class);
            startActivity(intent);

        }


    }
}
